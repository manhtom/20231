package hust.soict.it4785.listviewexample

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class MyAdapter<T>(val context: Context, val lstUsers:List<T>): BaseAdapter()
{
    override fun getCount(): Int {
        return lstUsers.size
    }

    override fun getItem(p0: Int): T {
        val songItem = lstUsers.get(p0)
        return songItem
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    @SuppressLint("ResourceAsColor")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        var view = convertView
        val songItem = lstUsers.get(position) as SongModel
        if(view == null)
        {
            view = LayoutInflater.from(context).inflate(R.layout.listview_item, parent, false)
            val txtViewSongName = view!!.findViewById<TextView>(R.id.txtSongName)
            val txtViewSongAuthor = view!!.findViewById<TextView>(R.id.txtSongAuthor)

            txtViewSongName.text = songItem.songName
            txtViewSongAuthor.text = songItem.songAuthor

            val viewHolder = ViewHolder(txtViewSongName, txtViewSongAuthor)
            view.tag = viewHolder
        }
        else
        {
            //val txtViewSongName = view!!.findViewById<TextView>(R.id.txtSongName)
            //val txtViewSongAuthor = view!!.findViewById<TextView>(R.id.txtSongAuthor)
            //txtViewSongName.text = songItem.songName
            //txtViewSongAuthor.text = songItem.songAuthor
            val viewHolder = view.tag as ViewHolder
            if(viewHolder != null)
            {
                viewHolder.txtViewSongName.text = songItem.songName
                viewHolder.txtViewSongAuthor.text = songItem.songAuthor
            }
        }
        return view
    }


    private class ViewHolder(val txtViewSongName: TextView, val txtViewSongAuthor: TextView) {

    }
}
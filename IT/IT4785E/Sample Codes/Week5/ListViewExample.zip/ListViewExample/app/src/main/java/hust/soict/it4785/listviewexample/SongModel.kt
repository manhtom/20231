package hust.soict.it4785.listviewexample

class SongModel(val songName:String, val songAuthor:String) {
}
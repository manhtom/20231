package hust.soict.it4785.listviewexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import hust.soict.it4785.listviewexample.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding:ActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        val arrayAdapter: ArrayAdapter<*>
        val lstSongs = mutableListOf<SongModel>()

        for(i in 0..10000)
        {
            val songModel = SongModel("Song: " + i, "Son Tung")
            lstSongs.add(songModel)
        }

        val myAdapter = MyAdapter(this, lstSongs)
        //val a = myAdapter.getItem(0)

        binding.lvItems.adapter = myAdapter

    }
}
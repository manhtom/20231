package com.example.helloemptyviewactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnRoll: Button = findViewById(R.id.btnRoll)
        try {
            if(btnRoll != null)
            {
                val onClick = OnClickClass(this)

                //btnRoll.setOnClickListener(onClick)
                /*btnRoll.setOnClickListener(object: View.OnClickListener{
                    override fun onClick(p0: View?) {
                        Toast.makeText(this@MainActivity, "Abc", Toast.LENGTH_SHORT).show()
                    }

                })*/
                //btnRoll.setOnClickListener(this);
                btnRoll.setOnClickListener {
                    Toast.makeText(this, "abc", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            TODO("Not yet implemented")
        }
    }

    class OnClickClass(private val mainActivity: MainActivity) : View.OnClickListener
    {
        override fun onClick(p0: View?) {
            Toast.makeText(mainActivity, "Hello", Toast.LENGTH_LONG).show()
        }

    }

    override fun onClick(p0: View?) {
        Toast.makeText(this, "Hello", Toast.LENGTH_LONG).show()
        rollDice()
    }

    private fun rollDice() {
        val dice = Dice(6)
        val number = dice.roll()

        val txtHello = findViewById<TextView>(R.id.txtHello)
        txtHello.text = number.toString()

        val diceImage = findViewById<ImageView>(R.id.imageView)
        val diceResourceId = when(number)
        {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        diceImage.setImageResource(diceResourceId)
    }

    class Dice(val numSides: Int)
    {
        fun roll(): Int
        {
            return (1..numSides).random()
        }
    }
}